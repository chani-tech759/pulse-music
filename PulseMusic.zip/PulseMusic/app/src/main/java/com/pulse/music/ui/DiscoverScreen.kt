package com.pulse.music.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.pulse.music.OnlineState
import com.pulse.music.Song

private val DiscoverGenres = listOf(
    "Electronic", "Hip-Hop/Rap", "Pop", "Rock", "Lo-Fi",
    "Ambient", "Jazz", "R&B/Soul", "Classical", "Folk"
)

@Composable
fun DiscoverScreen(
    state: OnlineState,
    query: String,
    genre: String?,
    favoriteIds: Set<String>,
    currentId: String?,
    onQueryChange: (String) -> Unit,
    onGenreChange: (String?) -> Unit,
    onPlay: (Song) -> Unit,
    onToggleFavorite: (Song) -> Unit,
    onRetry: () -> Unit
) {
    Column(modifier = Modifier.fillMaxSize()) {
        ScreenHeader(title = "Discover", subtitle = "Free music from independent artists")

        AppSearchField(
            query = query,
            onQueryChange = onQueryChange,
            placeholder = "Search tracks and artists",
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp)
        )

        if (query.isBlank()) {
            LazyRow(
                modifier = Modifier.padding(top = 12.dp),
                contentPadding = PaddingValues(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                item {
                    GenreChip(label = "All", selected = genre == null) { onGenreChange(null) }
                }
                items(DiscoverGenres) { name ->
                    GenreChip(label = name, selected = genre == name) { onGenreChange(name) }
                }
            }
        }

        Text(
            text = when {
                query.isNotBlank() -> "Results for \"${query.trim()}\""
                genre != null -> "Trending in $genre"
                else -> "Trending this week"
            },
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.SemiBold,
            color = MaterialTheme.colorScheme.onBackground,
            modifier = Modifier.padding(start = 20.dp, end = 20.dp, top = 16.dp, bottom = 4.dp)
        )

        Box(modifier = Modifier.weight(1f)) {
            when {
                state.loading -> CircularProgressIndicator(
                    modifier = Modifier.align(Alignment.Center),
                    color = MaterialTheme.colorScheme.primary
                )

                state.error != null -> EmptyState(
                    title = "You're offline?",
                    message = state.error,
                    action = { Button(onClick = onRetry) { Text("Try again") } }
                )

                state.tracks.isEmpty() -> EmptyState(
                    title = "Nothing here",
                    message = if (query.isNotBlank()) "No tracks match your search."
                    else "No tracks came back for this genre. Try another one."
                )

                else -> LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    items(state.tracks, key = { it.id }) { song ->
                        TrackRow(
                            song = song,
                            isCurrent = currentId == song.id,
                            onClick = { onPlay(song) },
                            isFavorite = song.id in favoriteIds,
                            onToggleFavorite = { onToggleFavorite(song) }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun GenreChip(label: String, selected: Boolean, onClick: () -> Unit) {
    FilterChip(
        selected = selected,
        onClick = onClick,
        label = { Text(label) },
        colors = FilterChipDefaults.filterChipColors(
            selectedContainerColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.22f),
            selectedLabelColor = MaterialTheme.colorScheme.primary
        )
    )
}
