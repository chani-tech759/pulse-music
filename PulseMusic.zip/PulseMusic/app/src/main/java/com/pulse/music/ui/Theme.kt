package com.pulse.music.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Ink = Color(0xFF0E0E13)
val Panel = Color(0xFF16161D)
val PanelRaised = Color(0xFF211F2D)
val Violet = Color(0xFFA897FF)
val Mint = Color(0xFF5EE0C2)
val Mist = Color(0xFFECEAF4)
val MistDim = Color(0xFFA5A3B5)

private val PulseColors = darkColorScheme(
    primary = Violet,
    onPrimary = Color(0xFF1B1140),
    secondary = Mint,
    onSecondary = Color(0xFF00382D),
    background = Ink,
    onBackground = Mist,
    surface = Panel,
    onSurface = Mist,
    surfaceVariant = PanelRaised,
    onSurfaceVariant = MistDim,
    outline = Color(0xFF4A4858)
)

@Composable
fun PulseTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = PulseColors, content = content)
}
