package com.pulse.music

import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/**
 * Minimal client for the Audius public REST API: free, full-length streaming of
 * tracks uploaded by independent artists. No account or API key is needed, only
 * an app name so Audius can see which apps use it.
 *
 * To stream from a different catalogue (Jamendo, your own server, ...), this is
 * the only file that has to change: return a List<Song> from trending() and
 * search(), and build a playable Uri in streamUri().
 */
object AudiusApi {

    private const val APP_NAME = "PulseMusic"
    private const val DISCOVERY_URL = "https://api.audius.co"

    /** Host currently used for requests and stream URLs. Replaced if it stops answering. */
    @Volatile
    private var host: String = DISCOVERY_URL

    suspend fun trending(genre: String?, limit: Int = 40): List<Song> {
        val genreParam = if (genre.isNullOrBlank()) "" else "&genre=${encode(genre)}"
        val body = get("/v1/tracks/trending?time=week&limit=$limit$genreParam&app_name=$APP_NAME")
        return parseTracks(body)
    }

    suspend fun search(query: String, limit: Int = 40): List<Song> {
        val body = get("/v1/tracks/search?query=${encode(query)}&limit=$limit&app_name=$APP_NAME")
        return parseTracks(body)
    }

    /** Audius answers this URL with a redirect to the audio file; ExoPlayer follows it. */
    fun streamUri(rawTrackId: String): Uri =
        Uri.parse("$host/v1/tracks/$rawTrackId/stream?app_name=$APP_NAME")

    // ---- Networking ----------------------------------------------------------

    private suspend fun get(path: String): String = withContext(Dispatchers.IO) {
        var lastError: IOException? = null

        try {
            return@withContext httpGet(host + path)
        } catch (e: IOException) {
            lastError = e
        }

        // The current host failed: ask Audius for its list of hosts and try a couple.
        val alternatives = try {
            discoverHosts().filter { it != host }.take(2)
        } catch (e: IOException) {
            lastError = e
            emptyList()
        }
        for (candidate in alternatives) {
            try {
                val body = httpGet(candidate + path)
                host = candidate
                return@withContext body
            } catch (e: IOException) {
                lastError = e
            }
        }
        throw lastError ?: IOException("No Audius host reachable")
    }

    private fun discoverHosts(): List<String> {
        val data = JSONObject(httpGet(DISCOVERY_URL)).optJSONArray("data") ?: return emptyList()
        return (0 until data.length()).mapNotNull { i ->
            data.optString(i).takeIf { it.startsWith("https://") }
        }.shuffled()
    }

    private fun httpGet(url: String): String {
        val connection = URL(url).openConnection() as HttpURLConnection
        try {
            connection.connectTimeout = 10_000
            connection.readTimeout = 15_000
            connection.setRequestProperty("Accept", "application/json")
            val code = connection.responseCode
            if (code !in 200..299) throw IOException("HTTP $code for $url")
            return connection.inputStream.bufferedReader().use { it.readText() }
        } finally {
            connection.disconnect()
        }
    }

    // ---- Parsing -------------------------------------------------------------

    private fun parseTracks(body: String): List<Song> {
        val data: JSONArray = JSONObject(body).optJSONArray("data") ?: return emptyList()
        val songs = ArrayList<Song>(data.length())
        for (i in 0 until data.length()) {
            val track = data.optJSONObject(i) ?: continue
            val id = track.text("id")
            if (id.isBlank()) continue
            if (track.has("is_streamable") && !track.optBoolean("is_streamable", true)) continue

            val artwork = track.optJSONObject("artwork")
            val artworkUrl = artwork?.let {
                it.text("480x480").ifBlank { it.text("1000x1000") }.ifBlank { it.text("150x150") }
            }.orEmpty()

            songs += Song(
                id = "${Song.ONLINE_PREFIX}$id",
                title = track.text("title").ifBlank { "Untitled" },
                artist = track.optJSONObject("user")?.text("name").orEmpty().ifBlank { "Unknown artist" },
                album = track.text("genre").ifBlank { "Audius" },
                durationMs = track.optLong("duration", 0L) * 1000L, // Audius reports seconds
                uri = null,
                artworkUri = artworkUrl.takeIf { it.isNotBlank() }?.let(Uri::parse)
            )
        }
        return songs
    }

    /** optString() turns a JSON null into the text "null"; this returns "" instead. */
    private fun JSONObject.text(key: String): String = if (isNull(key)) "" else optString(key)

    private fun encode(value: String): String = URLEncoder.encode(value, "UTF-8")
}
