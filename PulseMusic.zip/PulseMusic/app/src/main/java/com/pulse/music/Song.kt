package com.pulse.music

import android.net.Uri

data class Song(
    /** "local:<mediastore id>" for files on the phone, "audius:<track id>" for streamed tracks. */
    val id: String,
    val title: String,
    val artist: String,
    val album: String,
    val durationMs: Long,
    /** Content URI of a file on the phone. Null for online tracks, whose stream URL is built when played. */
    val uri: Uri?,
    val artworkUri: Uri?
) {
    val isOnline: Boolean get() = id.startsWith(ONLINE_PREFIX)

    companion object {
        const val LOCAL_PREFIX = "local:"
        const val ONLINE_PREFIX = "audius:"
    }
}
