package com.pulse.music.ui

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.Shuffle
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import com.pulse.music.Song

/**
 * The "On this phone" tab. Audio permission is only asked for here, so
 * someone who just wants to stream is never prompted for file access.
 */
@Composable
fun LocalTab(
    songs: List<Song>,
    totalCount: Int,
    loading: Boolean,
    query: String,
    currentId: String?,
    onQueryChange: (String) -> Unit,
    onPlay: (Song) -> Unit,
    onShuffle: () -> Unit,
    onLoad: () -> Unit
) {
    val context = LocalContext.current

    val audioPermission = if (Build.VERSION.SDK_INT >= 33) {
        Manifest.permission.READ_MEDIA_AUDIO
    } else {
        Manifest.permission.READ_EXTERNAL_STORAGE
    }

    fun hasAudioPermission() =
        ContextCompat.checkSelfPermission(context, audioPermission) == PackageManager.PERMISSION_GRANTED

    var granted by remember { mutableStateOf(hasAudioPermission()) }

    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        granted = isGranted
        if (isGranted) onLoad()
    }

    // On first view, and when coming back from system settings or after adding new music.
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) {
        granted = hasAudioPermission()
        if (granted) onLoad()
    }

    if (!granted) {
        PermissionPrompt(
            onAllow = { permissionLauncher.launch(audioPermission) },
            onOpenSettings = {
                context.startActivity(
                    Intent(
                        Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                        Uri.fromParts("package", context.packageName, null)
                    )
                )
            }
        )
        return
    }

    Column(modifier = Modifier.fillMaxSize()) {
        ScreenHeader(
            title = "On this phone",
            subtitle = when (totalCount) {
                0 -> null
                1 -> "1 song"
                else -> "$totalCount songs"
            },
            trailing = {
                if (songs.isNotEmpty()) {
                    FilledTonalButton(onClick = onShuffle) {
                        Icon(Icons.Rounded.Shuffle, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(8.dp))
                        Text("Shuffle")
                    }
                }
            }
        )

        AppSearchField(
            query = query,
            onQueryChange = onQueryChange,
            placeholder = "Search songs, artists, albums",
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp)
        )
        Spacer(Modifier.height(8.dp))

        Box(modifier = Modifier.weight(1f)) {
            when {
                loading && totalCount == 0 -> CircularProgressIndicator(
                    modifier = Modifier.align(Alignment.Center),
                    color = MaterialTheme.colorScheme.primary
                )

                totalCount == 0 -> EmptyState(
                    title = "No music found",
                    message = "Copy some songs onto this phone, then reopen Pulse."
                )

                songs.isEmpty() -> EmptyState(
                    title = "No matches",
                    message = "Nothing on this phone matches \"$query\"."
                )

                else -> LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    items(songs, key = { it.id }) { song ->
                        TrackRow(
                            song = song,
                            isCurrent = currentId == song.id,
                            onClick = { onPlay(song) }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun PermissionPrompt(onAllow: () -> Unit, onOpenSettings: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(
            imageVector = Icons.Rounded.MusicNote,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.primary,
            modifier = Modifier.size(64.dp)
        )
        Spacer(Modifier.height(20.dp))
        Text(
            text = "Play the music on this phone too",
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onBackground,
            textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(10.dp))
        Text(
            text = "Allow access to audio files to see your downloaded songs here. " +
                "They stay on your device.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(24.dp))
        Button(onClick = onAllow) { Text("Allow access") }
        TextButton(onClick = onOpenSettings) { Text("Open app settings") }
    }
}
