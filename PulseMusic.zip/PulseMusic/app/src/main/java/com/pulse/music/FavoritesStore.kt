package com.pulse.music

import android.content.Context
import android.net.Uri
import org.json.JSONArray
import org.json.JSONObject

/**
 * Saves the tracks the person hearts. Only metadata is stored; the stream URL is
 * rebuilt when a track is played, so it keeps working if the host changes.
 */
class FavoritesStore(context: Context) {

    private val prefs = context.getSharedPreferences("pulse_favorites", Context.MODE_PRIVATE)

    fun load(): List<Song> {
        val raw = prefs.getString(KEY, null) ?: return emptyList()
        return runCatching {
            val array = JSONArray(raw)
            (0 until array.length()).mapNotNull { i ->
                val o = array.optJSONObject(i) ?: return@mapNotNull null
                val id = o.optString("id")
                if (id.isBlank()) return@mapNotNull null
                Song(
                    id = id,
                    title = o.optString("title"),
                    artist = o.optString("artist"),
                    album = o.optString("album"),
                    durationMs = o.optLong("durationMs"),
                    uri = null,
                    artworkUri = o.optString("artwork").takeIf { it.isNotBlank() }?.let(Uri::parse)
                )
            }
        }.getOrDefault(emptyList())
    }

    fun save(songs: List<Song>) {
        val array = JSONArray()
        songs.forEach { song ->
            array.put(
                JSONObject()
                    .put("id", song.id)
                    .put("title", song.title)
                    .put("artist", song.artist)
                    .put("album", song.album)
                    .put("durationMs", song.durationMs)
                    .put("artwork", song.artworkUri?.toString().orEmpty())
            )
        }
        prefs.edit().putString(KEY, array.toString()).apply()
    }

    private companion object {
        const val KEY = "tracks"
    }
}
