package com.pulse.music

import android.app.Application
import android.content.ComponentName
import android.net.Uri
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.ListenableFuture
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

/** Everything the UI needs to know about playback, in one immutable snapshot. */
data class PlayerUi(
    val hasMedia: Boolean = false,
    val mediaId: String? = null,
    val title: String = "",
    val artist: String = "",
    val artworkUri: Uri? = null,
    /** True when the player is playing or is about to (e.g. still buffering). */
    val isPlaying: Boolean = false,
    val buffering: Boolean = false,
    val positionMs: Long = 0L,
    val durationMs: Long = 0L,
    val shuffle: Boolean = false,
    val repeatMode: Int = Player.REPEAT_MODE_OFF
) {
    val isOnline: Boolean get() = mediaId?.startsWith(Song.ONLINE_PREFIX) == true
}

/** What the Discover tab is showing: trending tracks or search results. */
data class OnlineState(
    val loading: Boolean = false,
    val error: String? = null,
    val tracks: List<Song> = emptyList()
)

class MusicViewModel(app: Application) : AndroidViewModel(app) {

    // ==== On this phone =======================================================

    private val repository = MusicRepository(app)

    private val _songs = MutableStateFlow<List<Song>>(emptyList())
    val songs: StateFlow<List<Song>> = _songs.asStateFlow()

    private val _loading = MutableStateFlow(false)
    val loading: StateFlow<Boolean> = _loading.asStateFlow()

    private val _query = MutableStateFlow("")
    val query: StateFlow<String> = _query.asStateFlow()

    /** The phone library after applying the search box. */
    val filtered: StateFlow<List<Song>> = combine(_songs, _query) { list, q ->
        val needle = q.trim()
        if (needle.isEmpty()) {
            list
        } else {
            list.filter {
                it.title.contains(needle, ignoreCase = true) ||
                    it.artist.contains(needle, ignoreCase = true) ||
                    it.album.contains(needle, ignoreCase = true)
            }
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    private var loadJob: Job? = null

    fun loadSongs() {
        if (loadJob?.isActive == true) return
        loadJob = viewModelScope.launch {
            _loading.value = true
            _songs.value = runCatching { repository.loadSongs() }.getOrDefault(emptyList())
            _loading.value = false
        }
    }

    fun setQuery(value: String) {
        _query.value = value
    }

    // ==== Discover (online) ===================================================

    private val _discover = MutableStateFlow(OnlineState(loading = true))
    val discover: StateFlow<OnlineState> = _discover.asStateFlow()

    private val _discoverQuery = MutableStateFlow("")
    val discoverQuery: StateFlow<String> = _discoverQuery.asStateFlow()

    private val _genre = MutableStateFlow<String?>(null)
    val genre: StateFlow<String?> = _genre.asStateFlow()

    private var discoverJob: Job? = null

    /** Loads trending tracks (for the chosen genre) or, if there is a search, its results. */
    fun refreshDiscover(debounceMs: Long = 0L) {
        discoverJob?.cancel()
        discoverJob = viewModelScope.launch {
            if (debounceMs > 0) delay(debounceMs)
            _discover.value = OnlineState(loading = true)
            val q = _discoverQuery.value.trim()
            try {
                val tracks = if (q.isEmpty()) AudiusApi.trending(_genre.value) else AudiusApi.search(q)
                _discover.value = OnlineState(tracks = tracks)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _discover.value = OnlineState(
                    error = "Couldn't load music. Check your internet connection and try again."
                )
            }
        }
    }

    fun setDiscoverQuery(value: String) {
        _discoverQuery.value = value
        // Wait for a pause in typing before hitting the network.
        refreshDiscover(debounceMs = if (value.isBlank()) 0L else 400L)
    }

    fun selectGenre(genre: String?) {
        _genre.value = genre
        refreshDiscover()
    }

    // ==== Favorites ===========================================================

    private val favoritesStore = FavoritesStore(app)

    private val _favorites = MutableStateFlow(favoritesStore.load())
    val favorites: StateFlow<List<Song>> = _favorites.asStateFlow()

    val favoriteIds: StateFlow<Set<String>> = _favorites
        .map { list -> list.map { it.id }.toSet() }
        .stateIn(
            viewModelScope,
            SharingStarted.Eagerly,
            _favorites.value.map { it.id }.toSet()
        )

    fun toggleFavorite(song: Song) {
        if (!song.isOnline) return
        _favorites.update { current ->
            if (current.any { it.id == song.id }) {
                current.filterNot { it.id == song.id }
            } else {
                listOf(song) + current
            }
        }
        favoritesStore.save(_favorites.value)
    }

    /** Hearts the track that is playing right now, built from the player's own metadata. */
    fun toggleFavoriteCurrent() {
        val c = controller ?: return
        val item = c.currentMediaItem ?: return
        val meta = item.mediaMetadata
        toggleFavorite(
            Song(
                id = item.mediaId,
                title = meta.title?.toString().orEmpty(),
                artist = meta.artist?.toString().orEmpty(),
                album = meta.albumTitle?.toString().orEmpty(),
                durationMs = if (c.duration == C.TIME_UNSET) 0L else c.duration.coerceAtLeast(0L),
                uri = null,
                artworkUri = meta.artworkUri
            )
        )
    }

    // ==== Playback ============================================================

    private val _player = MutableStateFlow(PlayerUi())
    val player: StateFlow<PlayerUi> = _player.asStateFlow()

    /** One-off messages for the UI to show as a toast (playback failures). */
    private val _messages = MutableSharedFlow<String>(extraBufferCapacity = 4)
    val messages: SharedFlow<String> = _messages.asSharedFlow()

    private var controllerFuture: ListenableFuture<MediaController>? = null
    private var controller: MediaController? = null
    private var tickerJob: Job? = null

    private val playerListener = object : Player.Listener {
        override fun onEvents(player: Player, events: Player.Events) {
            syncFromController()
        }

        override fun onPlayerError(error: PlaybackException) {
            _messages.tryEmit("Couldn't play that track. Check your connection and try again.")
        }
    }

    init {
        connectToService()
        refreshDiscover()
    }

    private fun connectToService() {
        val context = getApplication<Application>()
        val token = SessionToken(context, ComponentName(context, PlaybackService::class.java))
        val future = MediaController.Builder(context, token).buildAsync()
        controllerFuture = future
        future.addListener(
            {
                val connected = runCatching { future.get() }.getOrNull() ?: return@addListener
                controller = connected
                connected.addListener(playerListener)
                syncFromController()
                startPositionTicker()
            },
            ContextCompat.getMainExecutor(context)
        )
    }

    /** Playing, or waiting to play (buffering). Idle (after an error) and ended count as not playing. */
    private fun Player.wantsToPlay(): Boolean =
        playWhenReady && playbackState != Player.STATE_IDLE && playbackState != Player.STATE_ENDED

    private fun syncFromController() {
        val c = controller ?: return
        val item = c.currentMediaItem
        _player.value = PlayerUi(
            hasMedia = item != null,
            mediaId = item?.mediaId,
            title = item?.mediaMetadata?.title?.toString().orEmpty(),
            artist = item?.mediaMetadata?.artist?.toString().orEmpty(),
            artworkUri = item?.mediaMetadata?.artworkUri,
            isPlaying = c.wantsToPlay(),
            buffering = c.wantsToPlay() && c.playbackState == Player.STATE_BUFFERING,
            positionMs = c.currentPosition.coerceAtLeast(0L),
            durationMs = if (c.duration == C.TIME_UNSET) 0L else c.duration.coerceAtLeast(0L),
            shuffle = c.shuffleModeEnabled,
            repeatMode = c.repeatMode
        )
    }

    /** The player only fires events on state changes, so poll the position while playing. */
    private fun startPositionTicker() {
        tickerJob?.cancel()
        tickerJob = viewModelScope.launch {
            while (isActive) {
                val c = controller
                if (c != null && c.isPlaying) {
                    val position = c.currentPosition.coerceAtLeast(0L)
                    _player.update { it.copy(positionMs = position) }
                }
                delay(500)
            }
        }
    }

    /** Plays [song] and queues everything in [queue] around it. */
    fun play(song: Song, queue: List<Song>) {
        val c = controller ?: return
        val index = queue.indexOfFirst { it.id == song.id }.coerceAtLeast(0)
        c.setMediaItems(queue.map { it.toMediaItem() }, index, 0L)
        c.prepare()
        c.play()
    }

    fun shuffleAll(queue: List<Song>) {
        val c = controller ?: return
        if (queue.isEmpty()) return
        c.shuffleModeEnabled = true
        c.setMediaItems(queue.map { it.toMediaItem() }, queue.indices.random(), 0L)
        c.prepare()
        c.play()
    }

    fun togglePlayPause() {
        val c = controller ?: return
        if (c.wantsToPlay()) {
            c.pause()
        } else {
            when (c.playbackState) {
                Player.STATE_IDLE -> c.prepare()                   // retry after an error
                Player.STATE_ENDED -> c.seekToDefaultPosition(0)  // replay the queue
            }
            c.play()
        }
    }

    fun next() {
        val c = controller ?: return
        c.seekToNextMediaItem()
        if (c.playbackState == Player.STATE_IDLE) c.prepare()
    }

    fun previous() {
        val c = controller ?: return
        // Like most players: restart the song first, go back only if it just began.
        if (c.currentPosition > 3_000) c.seekTo(0) else c.seekToPreviousMediaItem()
        if (c.playbackState == Player.STATE_IDLE) c.prepare()
    }

    fun seekTo(positionMs: Long) {
        controller?.seekTo(positionMs)
        _player.update { it.copy(positionMs = positionMs) }
    }

    fun toggleShuffle() {
        val c = controller ?: return
        c.shuffleModeEnabled = !c.shuffleModeEnabled
    }

    fun cycleRepeat() {
        val c = controller ?: return
        c.repeatMode = when (c.repeatMode) {
            Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
            Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
            else -> Player.REPEAT_MODE_OFF
        }
    }

    override fun onCleared() {
        tickerJob?.cancel()
        controller?.removeListener(playerListener)
        controllerFuture?.let { MediaController.releaseFuture(it) }
        controller = null
        super.onCleared()
    }
}

private fun Song.toMediaItem(): MediaItem {
    // Online tracks get their stream URL at play time, so a saved favourite
    // still works after the API host changes.
    val playUri = if (isOnline) {
        AudiusApi.streamUri(id.removePrefix(Song.ONLINE_PREFIX))
    } else {
        requireNotNull(uri) { "Local song without a content URI" }
    }
    return MediaItem.Builder()
        .setMediaId(id)
        .setUri(playUri)
        .setMediaMetadata(
            MediaMetadata.Builder()
                .setTitle(title)
                .setArtist(artist)
                .setAlbumTitle(album)
                .setArtworkUri(artworkUri)
                .build()
        )
        .build()
}
