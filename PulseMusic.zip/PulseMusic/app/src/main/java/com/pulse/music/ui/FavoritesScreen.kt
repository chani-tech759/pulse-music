package com.pulse.music.ui

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import com.pulse.music.Song
import androidx.compose.ui.unit.dp

@Composable
fun FavoritesScreen(
    favorites: List<Song>,
    currentId: String?,
    onPlay: (Song) -> Unit,
    onToggleFavorite: (Song) -> Unit
) {
    Column(modifier = Modifier.fillMaxSize()) {
        ScreenHeader(
            title = "Favorites",
            subtitle = when (favorites.size) {
                0 -> null
                1 -> "1 track"
                else -> "${favorites.size} tracks"
            }
        )

        if (favorites.isEmpty()) {
            EmptyState(
                title = "No favorites yet",
                message = "Tap the heart on any track in Discover and it will be saved here.",
                modifier = Modifier.weight(1f)
            )
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp)
            ) {
                items(favorites, key = { it.id }) { song ->
                    TrackRow(
                        song = song,
                        isCurrent = currentId == song.id,
                        onClick = { onPlay(song) },
                        isFavorite = true,
                        onToggleFavorite = { onToggleFavorite(song) }
                    )
                }
            }
        }
    }
}
