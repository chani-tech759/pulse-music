package com.pulse.music.ui

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Explore
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.PhoneAndroid
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.pulse.music.MusicViewModel

private enum class Tab(val label: String, val icon: ImageVector) {
    Discover("Discover", Icons.Rounded.Explore),
    Favorites("Favorites", Icons.Rounded.Favorite),
    Phone("On this phone", Icons.Rounded.PhoneAndroid)
}

@Composable
fun PulseApp(vm: MusicViewModel = viewModel()) {
    val context = LocalContext.current

    val player by vm.player.collectAsStateWithLifecycle()
    val discover by vm.discover.collectAsStateWithLifecycle()
    val discoverQuery by vm.discoverQuery.collectAsStateWithLifecycle()
    val genre by vm.genre.collectAsStateWithLifecycle()
    val favorites by vm.favorites.collectAsStateWithLifecycle()
    val favoriteIds by vm.favoriteIds.collectAsStateWithLifecycle()
    val phoneSongs by vm.filtered.collectAsStateWithLifecycle()
    val allPhoneSongs by vm.songs.collectAsStateWithLifecycle()
    val phoneLoading by vm.loading.collectAsStateWithLifecycle()
    val phoneQuery by vm.query.collectAsStateWithLifecycle()

    // Android 13+ hides the playback notification (and its lock-screen controls)
    // until the person allows notifications.
    val notificationLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { }
    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            notificationLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    // Playback failures (bad connection, track removed) arrive as one-off messages.
    LaunchedEffect(Unit) {
        vm.messages.collect { message ->
            Toast.makeText(context, message, Toast.LENGTH_SHORT).show()
        }
    }

    var tabIndex by rememberSaveable { mutableIntStateOf(0) }
    val tab = Tab.entries[tabIndex]

    var showPlayer by rememberSaveable { mutableStateOf(false) }
    val playerVisible = showPlayer && player.hasMedia
    BackHandler(enabled = playerVisible) { showPlayer = false }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
        ) {
            Box(modifier = Modifier.weight(1f)) {
                when (tab) {
                    Tab.Discover -> DiscoverScreen(
                        state = discover,
                        query = discoverQuery,
                        genre = genre,
                        favoriteIds = favoriteIds,
                        currentId = player.mediaId,
                        onQueryChange = vm::setDiscoverQuery,
                        onGenreChange = vm::selectGenre,
                        onPlay = { song -> vm.play(song, queue = discover.tracks) },
                        onToggleFavorite = vm::toggleFavorite,
                        onRetry = { vm.refreshDiscover() }
                    )

                    Tab.Favorites -> FavoritesScreen(
                        favorites = favorites,
                        currentId = player.mediaId,
                        onPlay = { song -> vm.play(song, queue = favorites) },
                        onToggleFavorite = vm::toggleFavorite
                    )

                    Tab.Phone -> LocalTab(
                        songs = phoneSongs,
                        totalCount = allPhoneSongs.size,
                        loading = phoneLoading,
                        query = phoneQuery,
                        currentId = player.mediaId,
                        onQueryChange = vm::setQuery,
                        onPlay = { song -> vm.play(song, queue = phoneSongs) },
                        onShuffle = { vm.shuffleAll(phoneSongs) },
                        onLoad = vm::loadSongs
                    )
                }
            }

            AnimatedVisibility(visible = player.hasMedia) {
                MiniPlayer(
                    player = player,
                    onTogglePlayPause = vm::togglePlayPause,
                    onNext = vm::next,
                    onOpen = { showPlayer = true }
                )
            }

            NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
                Tab.entries.forEachIndexed { index, entry ->
                    NavigationBarItem(
                        selected = index == tabIndex,
                        onClick = { tabIndex = index },
                        icon = { Icon(entry.icon, contentDescription = null) },
                        label = { Text(entry.label) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = MaterialTheme.colorScheme.primary,
                            selectedTextColor = MaterialTheme.colorScheme.primary,
                            indicatorColor = MaterialTheme.colorScheme.surfaceVariant,
                            unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                            unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    )
                }
            }
        }

        AnimatedVisibility(
            visible = playerVisible,
            enter = slideInVertically { it },
            exit = slideOutVertically { it }
        ) {
            NowPlayingScreen(
                player = player,
                onClose = { showPlayer = false },
                onTogglePlayPause = vm::togglePlayPause,
                onNext = vm::next,
                onPrevious = vm::previous,
                onSeek = vm::seekTo,
                onToggleShuffle = vm::toggleShuffle,
                onCycleRepeat = vm::cycleRepeat,
                isFavorite = player.mediaId in favoriteIds,
                onToggleFavorite = vm::toggleFavoriteCurrent
            )
        }
    }
}
