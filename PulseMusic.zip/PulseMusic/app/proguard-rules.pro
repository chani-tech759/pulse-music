# Project-specific ProGuard / R8 rules go here.
# Minification is currently disabled in app/build.gradle.kts.
