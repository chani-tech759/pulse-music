# Pulse: a music streaming app for Android

Stream free music over the internet and play the songs stored on your phone, in one app.
Built with Kotlin, Jetpack Compose and Media3 (ExoPlayer).

## What it does

- **Discover**: trending tracks, genre chips and search, streamed from the Audius public API
  (free, full-length tracks from independent artists; no account or API key needed).
- **Favorites**: tap the heart on any streamed track to save it. Saved on the phone.
- **On this phone**: plays the audio files already on the device. Storage permission is only
  asked for when you open this tab.
- **Background playback**: music keeps playing when the app is closed, with a notification,
  lock-screen controls and headset buttons (Media3 `MediaSessionService`).
- Mini player, full Now Playing screen with seek bar, shuffle, repeat, next/previous.

## Run it

1. Open the `PulseMusic` folder in **Android Studio** (Ladybug or newer). Let Gradle sync.
2. Plug in a phone (USB debugging on) or start an emulator, API 26 or higher.
3. Press **Run**. To build an installable file: *Build > Build APK(s)*.

The first sync downloads the dependencies, so it needs an internet connection.

## Get an APK

- **Android Studio:** *Build > Build APK(s)*. The file is
  `app/build/outputs/apk/debug/app-debug.apk`.
- **Command line** (needs JDK 17 and the Android SDK): `./gradlew assembleDebug`.
- **Without installing anything:** put the contents of this folder in a new GitHub repository
  (the folder's contents, so `gradlew` and `.github` sit at the top level). The included
  workflow `.github/workflows/build-apk.yml` builds the APK on every push. Open the repo's
  **Actions** tab, pick the latest run and download **Pulse-debug-apk**. You can also start a
  build by hand with **Run workflow**.

The debug APK is signed with Android's debug key, so it installs on any phone (allow
"Install unknown apps" for your browser or file manager). It is not meant for the Play Store.

## Where things are

| File | Role |
| --- | --- |
| `AudiusApi.kt` | The only online catalogue code: `trending()`, `search()`, `streamUri()` |
| `PlaybackService.kt` | Owns the player; background playback and notification |
| `MusicViewModel.kt` | State for Discover, Favorites, the phone library and playback |
| `FavoritesStore.kt` | Saves favorites (metadata only) in SharedPreferences |
| `MusicRepository.kt` | Reads the phone's audio files through MediaStore |
| `ui/` | Compose screens: Discover, Favorites, On this phone, Now Playing |

## Using a different music source

Everything online goes through `AudiusApi.kt`. To use another catalogue (for example Jamendo,
which needs a free client id, or your own server), return a `List<Song>` from `trending()` and
`search()` and build a playable URL in `streamUri()`. Nothing else has to change.

## About Spotify

Spotify's own catalogue cannot be streamed from a custom player: Spotify's terms only allow
playback through its official SDK, which controls the Spotify app and needs a Premium
account. That is why Pulse streams from an open catalogue instead. Audius has plenty of
electronic, hip-hop, lo-fi and indie music, but not major-label hits.

## Notes

- Streams need a connection; there is no offline download of streamed tracks yet.
- The app is portrait-only and uses a dark theme.
